var menu = document.querySelector('.menu');
var button = document.querySelector('.button');

button.addEventListener('click', function(){
    menu.classList.toggle('open');

})